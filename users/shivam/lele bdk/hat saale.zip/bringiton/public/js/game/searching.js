

counter=0;


function doFirst(){

			speed=5000;
			if(counter==5)
			{
			 clearTimeout(setTimeout);
			
			}

			xml();
			
			if(counter<5){
			counter++;
			setTime=setTimeout('doFirst()',speed);	
			}			

			// else{
			// 	clearTimeout(setTimeout);
			// }	
	
			}
function warning()
	{
			return "You will loose the game if you refresh or close the window";
	}

	window.addEventListener('load',doFirst,false);

