

<!-- why the hell is js not working in this file -->
<!-- <script type="text/javascript" src="js/admin/view_questions.js"></script> -->


<?php
	foreach ($new_questions as $object) 
	{
		echo($object->question."<br>");
		echo($object->option1."<br>");
		echo($object->option2."<br>");
		echo($object->option3."<br>");
		echo($object->option4."<hr>");

	}
?>
<button onclick="add_topic(<?php echo("'".$new_questions[0]->topic."'");?>)">Add</button>
<button onclick="delete_topic(<?php echo("'".$new_questions[0]->topic."'");?>)">Delete</button>