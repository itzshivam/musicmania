
@extends('layouts/app')


@section('content')

<script type="text/javascript" src="/js/profile/display.js"></script>

<div class="container">
<div class="row">
  	<div class="col-md-4 profile-sidebar" >
  		<?php

  			$src="/images/profile/".$profile_user->username;
  			if(file_exists($src."png"))
  			{
  				$src.="png";
  			}

  			else if(file_exists($src."jpg"))
  			{
  				$src.="jpg";
  			}

  			else if(file_exists($src."jpeg"))
  			{
  				$src.="jpeg";
  			}

  			else
  			{
  				$src="/images/profile/admin.jpg";
  			}
  			$str="<img width='200' height='200' class='profile-pic img-circle' src='".$src."'/>";
  			echo($str);
  			$win=1;
  			$draw=2;
  			$lost=3;
  			$total=$win+$lost+$draw;
  		?>
  		<br><br>
  		<button class="btn btn-info glyphicon glyphicon-circle-arrow-right"> PLAY</button>

  		<div class="user_performance">
  			<span   style=<?php echo("'width:".($win*120)/$total."'");?>>win</span>
  			<span style=<?php echo("'width:".($draw*120)/$total."'");?>>draw</span>
  			<span  style=<?php echo("'width:".($lost*120)/$total."'");?>>lost</span>  			
  		</div>
  	
  		<div class="user_performance">
  			<span>win</span>
  			<span>draw</span>
  			<span>lost</span>  			
  		</div>
  		<div class="user_performance">
  			<span><?php echo($profile_user->games_win);?></span>
  			<span>draw</span>
  			<span><?php echo($profile_user->games_played-$profile_user->games_win);?></span>  			
  		</div>
      <div id="active">

      Acitve : 
       <?php
   
        $time_difference=(time()-strtotime($profile_user->updated_at));
        echo($profile_user->updated_at);
        echo($time_difference);

        if($time_difference>35)
        {
          echo(round(($time_difference/60),2). " minutes ago");
        }

        else echo("Now");
      ?>
      </div>
      <canvas id="ring"></canvas>
  		
  	</div>
  	<div class="col-md-8">
       <?php
       echo("fsf");
          $opponent=explode(',',$profile_user->opponents);
          $score=explode(',', $profile_user->scores);
          $topic=explode(',',$profile_user->topics);
          $result=explode(',', $profile_user->results);
          $length=count($opponent)-1;
          for($i=0;$i<$length;$i++)
          {
          
          $str="<div>".
              $profile_user->username." ".$result[$i]." ".$opponent[$i]." in ".$topic[$i]
          ."</div>";
          echo ($str);
        }
       ?>
    </div>
</div>
</div>
@endsection