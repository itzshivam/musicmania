

<textarea placeholder="Write your question here" id="question" style="width:80%;min-height:50px;height: auto">
</textarea>
<br>
<input placeholder="correct answer" id="option1" type="text">	
<br>	
<input placeholder="incorrect answer" id="option2" type="text">		
<br>				
<input placeholder="incorrect answer" id="option3" type="text">		
<br>
<input placeholder="incorrect answer" id="option4" type="text">
<br>
<input type="file" id="file">
