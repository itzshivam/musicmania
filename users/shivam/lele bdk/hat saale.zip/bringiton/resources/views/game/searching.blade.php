@extends('layouts.app')

@section('content')





<!DOCTYPE html>

<?php

?>
<body onbeforeunload="return warning()">
 	<div id="hidden">hidden</div>
</body>

<head>

	<script type="text/javascript" src="/js/game/searching.js"></script>
	<script type="text/javascript" src="/js/game/playing.js"></script>
</head>
	<script type="text/javascript">

	function xml()
	{	
	
		if(counter<5){
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.onreadystatechange=function()
		{
			if(xmlhttp.readyState==4 && xmlhttp.status==200)
			{

			document.getElementById('hidden').innerHTML=xmlhttp.responseText;
			if(document.getElementById('qid'))
			{
				// get_questions();
				// show_questions();
				counter=5;
				clearTimeout(setTimeout);	
				display_question();		
			}
			
			if(document.getElementById('players'))
			{
				counter=5;
				clearTimeout(setTimeout);			
			}
			}
		}
		xmlhttp.open("GET","/topics/"+<?php echo("'".$topic."'");?>+"/searching");
		xmlhttp.send();
	}

	}


	


	</script>
</head>


<?php


use App\Info;
?>


@endsection