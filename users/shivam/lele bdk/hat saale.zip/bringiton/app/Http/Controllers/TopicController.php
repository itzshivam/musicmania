<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;

use App\Question;

use App\Info;

use App\New_question;

use DB;
use Illuminate\Support\Facades\Redirect;

use App\Http\Controllers\Controller;
use App\Http\Requests;

class TopicController extends Controller
{
   
   public function __construct()
    {
        $this->middleware('auth');
    }

   public function display_all()
   {
   		$topics_list = Question::select('topic','category')->distinct()->get();
   		// return "hello";
      // return Redirect::to('home');
   		return view('/topics/all',compact('topics_list'));
   } 

   public function display($topic)
   {
   		$topic=Question::where('topic',$topic)->first();
      // $ranklist=Info::select(DB::raw('(games_played) * (games_win) as rank'))->orderBy('games_played*games_win','asc')->get();
   	 	// echo(Info::get_user('itzshivam'));
      return view('/topics/selected',compact('topic'));

   }

   public function create()
   {
      $user=Auth::user();
      return view('/create/topic',compact('user'));
   }

   public function create_question()
   {

      return view('/create/question');
   }   


   public function submit_questions($topic,$category,$questions,$length)
   {
      
      // how to pass array using url and retrieve
    // print_r($questions);
    $str=explode(',', $questions);
 
    
      for($i=0;$i<$length;$i++)
      {
      $update=New_question::insert(['username'=>Auth::user()->username,
            'topic'=>$topic,
            'category'=>$category,
            'question'=>$str[$i*6],
            'option1'=>$str[$i*6+1],
            'option2'=>$str[$i*6+2],
            'option3'=>$str[$i*6+3],
            'option4'=>$str[$i*6+4],
            ]);

      }


     
   
     // $redirect="
     // <script> document.location='".url("/home")."'</script>";
     // echo($redirect);

   }
   

  function search($search_input)
  {
    $str_match = array();
    $all_topics=Question::select('topic')->distinct()->get();
    foreach ($all_topics as $topic)
    {
      $ans=0;
      $s2=strlen($search_input);

      $current_topic=strtolower($topic->topic);
      $size=strlen($current_topic);
      $search=strtolower($search_input);
      // echo("song ".$song." ".($size-$s2)."  <br>");
      for( $i=0;$i<=($size-$s2);$i++)
      {
        $ans2=0;
        // echo("i ".$i." <br>");
        for($j=0;$j<$s2;$j++)
        {
          // echo("j ".$j." <br>");
          $k=$j;        
          $ans3=0;
          while($k<$s2  && $current_topic[$i+$k]==$search[$k]  )
          {
          
            $ans3++;
            $k=$k+1;
            // echo("ans2 ".$ans2."<br> ");
          }

          if($ans3>$ans2)
          {
            $ans2=$ans3;
          }
        }

        if($ans2>$ans)
        {
          $ans=$ans2;
        }
      }

      
      $str_match+=array($current_topic=>$ans);
        // echo(" ans ".$ans." location ".$current_topic."<br>");
        // print_r($str_match);

    }
      arsort($str_match);

    $count=0;
    /// do it again doing almost good 
    foreach ($str_match as $key => $value) {
    
    if($count>=5 || $value<($s2)/2)
      break;
      
      // $sql="SELECT DISTINCT song_location,song_name,song_link FROM songs WHERE song_location ='$key'";
      // $result=$connect->query($sql);


      $search_result=Question::select('topic','category')->where('topic',$key)->distinct()->first();
      $str="<a href='/topics/".$search_result->topic."'><li>".$search_result->topic."<br><span> Category : ".$search_result->category."<br></span></li></a>";
      echo($str);
    $count++;


  }


    // return $str_match;
    
  }


}

?>