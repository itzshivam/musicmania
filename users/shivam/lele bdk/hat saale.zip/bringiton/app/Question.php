<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    //

   public static function get_questions($topic)
     {
        return Question::where('topic',$topic)->get();;

     }

}
