<?php $__env->startSection('content'); ?>
<style type="text/css">
.galleryItem {
	color: #797478;
	font: 10px/1.5 Verdana, Helvetica, sans-serif;
	width: 16%;
	margin:  2% 2% 50px 2%;
	float: left;
	-webkit-transition: color 0.5s ease;
}
	@media  only screen and (max-width : 940px),
only screen and (max-device-width : 940px){
	.galleryItem {width: 21%;}
}

@media  only screen and (max-width : 720px),
only screen and (max-device-width : 720px){
	.galleryItem {width: 29.33333%;}
	.header h1 {font-size: 40px;}
}

@media  only screen and (max-width : 530px),
only screen and (max-device-width : 530px){
	.galleryItem {width: 46%;}
	.header h1 {font-size: 28px;}
}

@media  only screen and (max-width : 320px),
only screen and (max-device-width : 320px){
	.galleryItem {width: 96%;}
	.galleryItem img {width: 96%;}
	.galleryItem h3 {font-size: 18px;}
	.galleryItem p, .header p {font-size: 18px;}
	.header h1 {font-size: 70px;}
}
</style>
	<div class="container">
		   			
	<?php
	   foreach ($topics_list as  $topic_ob) {
	   	
	    $href="/topics/".$topic_ob->topic;
	   	$src="images/icons/".$topic_ob->topic;

	   	if(file_exists($src.".png"))
	   	{
	   		$src.=".png";
	   	
	   	}
	   	else
	   	{
	   		$src.=".jpg";
	   	}

	   	// do it

	   $str="<a href='".$href."'> <div class=\"galleryItem\">
			 <img overflow='hidden' width='50' height='50' class='img-circle' src='".$src."' alt=\"image here\" />
			 <h3>".$topic_ob->topic."</h3>
			 <p>Category : ".$topic_ob->category."</p>
			 </div></a>";

			 echo($str);
	   }
	?>
	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>