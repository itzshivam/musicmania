<?php $__env->startSection('content'); ?>

	
	<script type="text/javascript">
		name="";
		category="";
		questions=[];
		images=[];
		counter=1;
		question_num=0;
		function get_question()
		 {	
		 	question_num++;
			var xmlhttp=new XMLHttpRequest();
			xmlhttp.onreadystatechange=function()			
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					var question = document.createElement("div");
					question.id=question_num;
					question.innerHTML=xmlhttp.responseText;
					document.getElementById('questions').appendChild(question);
					if(counter<2)
					{
						var buttons=document.getElementById('buttons');
						// console.log(buttons.childNodes[3]);

						buttons.removeChild(buttons.childNodes[3]);
					}
				}
			}

			xmlhttp.open("GET","/create/question");
			xmlhttp.send();
		}
	

		function set_questions()
		{	

			min_questions_required=2;
			var length=document.getElementById('questions').childNodes.length;

			if(length>min_questions_required)
			{
				
				for(var i=1;i<=length;i++)
				{
					var que=document.getElementById(i).childNodes[0].value;
					var n=que.length;
					for(j=0;j<n;j++)
					{
						if(que[j]=='/')
						{
							que[j]='`';
						}
					}


					var option1=document.getElementById(i).childNodes[4].value;
					var n=option1.length;
					for(j=0;j<n;j++)
					{
						if(option1[j]=='/')
						{
							option1[j]='`';
						}
					}

					var option2=document.getElementById(i).childNodes[8].value;
					var n=option2.length;
					for(j=0;j<n;j++)
					{
						if(option2[j]=='/')
						{
							option2[j]='`';
						}
					}

					var option3=document.getElementById(i).childNodes[12].value;
					var n=option3.length;
					for(j=0;j<n;j++)
					{
						if(option3[j]=='/')
						{
							option3[j]='`';
						}
					}

					var option4=document.getElementById(i).childNodes[16].value;
					var n=option4.length;
					for(j=0;j<n;j++)
					{
						if(option4[j]=='/')
						{
							option4[j]='`';
						}
					}		

					var option5=document.getElementById(i).childNodes[20].value;
					var n=option5.length;
					for(j=0;j<n;j++)
					{
						if(option5[j]=='/')
						{
							option5[j]='`';
						}
					}	

					question=[];
					question.push(escape(que));
					question.push(escape(option1));
					question.push(escape(option2));
					question.push(escape(option3));
					question.push(escape(option4));
					question.push(escape(option5));
					questions.push(question);


				}
			}
			// counter++;
			// que=document.getElementById('question').value;
			// question=[];
			// question.push(escape(que));
			// for(var i=1;i<=4;i++)
			// question.push(escape(document.getElementById(i).value));
			// questions.push((question));
			// if(document.getElementById('file').value)
			// {
			// 	images.push(document.getElementById('file').value);
			// }
			// // document.getElementById('newfile').value=document.getElementById('file').value
			// get_question();


		}


		function update_topic()
		{
			
			name=escape(document.getElementById('name').value);
			category=escape(document.getElementById('category').value);
			get_question();//set_question
								
		}

		function submit_questions()
		{

			set_questions();

			var xmlhttp=new XMLHttpRequest();
			xmlhttp.onreadystatechange=function()			
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementsByClassName('panel-body')[0].innerHTML=counter+". "+xmlhttp.responseText;
					
					
				}
			}
			xmlhttp.open("GET","/submit/"+name+"/"+category+"/"+(questions)+"/"+questions.length,true);
			xmlhttp.send();
			document.location="/home";
		}


	</script>

	<div id=container>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Create Your Own Topics Here</div>

                <div class="panel-body">
          
                   Write Name and Category of the topic you want to create
                   <br>
                   Name <input type="text" id="name"  placeholder="name of topic">
                   <br>
                   Category <input type="text" id="category" placeholder="category of topic">
                   <div id="questions"></div>
                   <button class="btn btn-danger glyphicon glyphicon-circle-arrow-right" onclick="update_topic()"> Next </button>
                   <button class="btn btn-primary"  onclick="submit_questions()">Submit</button>
                </div>
            </div>
        </div>
    </div>
<!-- <div id="newfile"></div>
 -->    </div>
<?php $__env->stopSection(); ?>







	

<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>