<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class New_question extends Model
{
    //
}
