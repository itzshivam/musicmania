<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Info;

use App\Http\Controllers\Controller;

use Auth;
use App\Question;
use App\Http\Requests;

class GameController extends Controller
{
	// for authentication 

	public function __construct()
    {
        $this->middleware('auth');
    }

    // for finding pair 

   //  public static $topic;

   // public function set_topic($topic)
   // {

   //    self::$topic=$topic;
      

   // }

   // private function get_topic()
   // {

   //  return self::$topic;
   // }


   public function get_questions($topic)
     {
        return Question::where('topic',$topic)->get();;

     }


   public function searching($topic)
   { 

   
        echo($topic);
   	   $user=Auth::user();
   	   $self_status=Info::where('username',$user->username)->select('status')->first();
       $opponents=Info::where('topic',$topic)->where('status','waiting')->get();

        if(sizeof($self_status)>0 )
       {
       		 if($self_status->status!="waiting")
       		 {
       		 $opponent_arr=explode(" ", $self_status->status);
       		 $opponent=Info::where('username',$opponent_arr[2])->first();

       		 // echo("found");
           $questions=$this->get_questions($topic);
         	 return view('/game/playing',compact('opponent','questions')); 
         	}
       }

       if(sizeof($opponents)>1)
       {
       		echo("found");
       		foreach ($opponents as $player) 
       		{
         		if($player->username!=$user->username)
         		{
         			$opponent=$player;
         			Info::where('username',$user->username)->update(['status'=>'playing with '.$opponent->username]);
         			Info::where('username',$opponent->username)->update(['status'=>'playing with '.$user->username]);
              $questions=$this->get_questions();
         			return view('/game/playing',compact('opponent','questions')); 
         			break;
         		}
         		
         	}
       }

       // else
       // {
       //  $user=Auth::user();
       //   // echo "helghjlo";//view('/home',compact('user'));
       // }


   }


    public function play($topic)
   {
        // $this->set_topic("done");

        $user=Auth::user();

    		Info::where('username',$user->username)->update(['topic'=>$topic,'status'=>"waiting",'current_score'=>0]);
        // $opponents=Info::where('topic',$topic)->where('status','waiting')->get();

		    return view('/game/searching',compact('topic'));

   }

	public function validate_ans($question_id,$selected_option)
	{
		
		$user=Auth::user();
    $ans=Question::select('option1')->where('id',$question_id)->first();
    $points=0;
    $fixed_point=10;
    $time_remaining=10;
    echo($ans->option1." ".$selected_option);
    if($ans->option1==$selected_option)
    {
      $points=$time_remaining+$fixed_point;
    }

		Info::where('username',$user->username)->increment('current_score', $points);
		echo ("true");
	}


   public function display_scores()
   {
   		$user=Auth::user();
   		$user_score=Info::select('current_score')->where('username',$user->username)->first();
   		echo($user_score->current_score."<br>");
   		$status="playing with ".$user->username;
   		$opponent_score=Info::where('status',$status)->select('current_score')->first();
   		echo($opponent_score->current_score);
   }

   public function update_user_info($current_opponent,$opponent_score)
   {
      $user=Auth::user();
      $user_info=Info::get_info($user->username);
      $opponents=$user_info->opponents.$current_opponent.",";
      $my_scores=$user_info->my_scores.$user_info->current_score.",";
      $topics=$user_info->topics.$user_info->q4topic.",";
      $opponent_scores=$user_info->opponent_scores.$opponent_score.","  ;
      Info::where('username',$user->username)->update(['status'=>'online','current_score'=>0,'opponents'=>$opponents,'my_scores'=>$my_scores,'topics'=>$topics,'opponent_scores'=>$opponent_scores]);
      // $this->update_user_info()
   }

   // public function reset_score_and_status($topic,$my_score,$opponent_score)
   // {
      
   // }

   public function result()
   {
    return view('/game/result');
   }


}


