<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/



Route::group(['middleware' => ['web']], function () {
    //
    Route::auth();


    Route::get('/home', 'HomeController@index');


        //route for profile page
    Route::get('profile/{username}','ProfileController@display');

    Route::get('profile/update/update_online_info','ProfileController@update_online_info');

    
   // topics realted routes
    Route::get('/topics','TopicController@display_all');
    Route::get('/topics/search/{search_input}','TopicController@search');

    //route for getting particular topic
    Route::get('/topics/{topic_name}','TopicController@display');

    //route for playing the topic

    Route::get('/update_user_info/{current_opponent}/{opponent_score}','GameController@update_user_info');
    Route::get('/topics/{topic_name}/play','GameController@play');
    Route::get('/topics/{topic_name}/result','GameController@result');
    Route::get('/topics/{topic_name}/searching','GameController@searching');

    /// route for creating topic

   Route::get('create/topic','TopicController@create');
   Route::get('create/question','TopicController@create_question');
   Route::get('submit/{topic}/{category}/{questions}/{len}','TopicController@submit_questions');
    
    Route::get('add_new_topic',function()
         {
            return "admin create here";
         });


    // game related routes
    Route::get('/game/validate_ans/{question_id}/{selected_option}','GameController@validate_ans');

    Route::get('/game/display_scores','GameController@display_scores');

     // route for home page
    Route::get('/','HomeController@index');

    Route::get('/admin','AdminController@home');
    Route::get('/admin/{topic}/{category}/{username}/view','AdminController@view_questions');

    Route::get('/admin/add_topic/{id}','AdminController@add_topic');
    Route::get('/admin/delete_topic/{id}','AdminController@delete_topic');
    
});

Route::group(['middleware' => 'web'], function () {
    Route::auth();

    
});
