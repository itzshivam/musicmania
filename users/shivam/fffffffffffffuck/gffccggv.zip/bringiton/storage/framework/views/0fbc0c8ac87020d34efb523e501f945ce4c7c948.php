<head>
	<script type="text/javascript" src="/js/game/playing.js"></script>

</head>
<!-- <?php
	// use App\Question;
	// echo($opponent->username);
	// $questions=DB::table('questions')->where('topic',$opponent->topic)->select('question')->get();
	
	// foreach ($questions as $question_row) {
	// 	echo($question_row->question);

	// 	echo("<a onclick='validate_ans()'> 6</a>");
	// 	# code...
	// }
?>
 -->

<body bgcolor="white" onbeforeunload="return warning()">
<div id="found">not found</div>
<div id="scores">0 0</div>
<div id="opponent" >
<head> 
<script type="text/javascript">
	function fun()
	{
		console.log("hi");
	}
</script>
</head>
	
	
	

	 <?php echo($opponent->username); 
	 $str="<script> 
	 	function fun()
	 	{
	 		alert('hi');
	 	}
	 </script>";
	 echo($str);
	// foreach ($questions as $question) {
	// 	$que="<div class='question_box'>".$question->question."</div>";

	// 	echo($que);
	// 	$validate_ans="validate_ans(".$question->id.",this".")";
	// 	$option1="<div class='option_box' onclick='".$validate_ans."''>".$question->option1."</div>";
	// 	$option2="<div class='option_box' onclick='".$validate_ans."''>".$question->option2."</div>";
	// 	$option3="<div class='option_box' onclick='".$validate_ans."''>".$question->option3."</div>";
	// 	$option4="<div class='option_box' onclick='".$validate_ans."''>".$question->option4."</div>";

	// 	echo($option1);
	// 	echo($option2);
	// 	echo($option3);
	// 	echo($option4); 


	// }
	// ?>
</script>

</div>

</body>

<!--  this is que format -->

<div class="container-fluid bg-info">
    <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <h3><span class="label label-warning" id="qid"> THREE is CORRECT</span>></h3>
        </div>
        <div class="modal-body">
            <div class="col-xs-3 col-xs-offset-5">
               <div id="loadbar" style="display: none;">
                  <div class="blockG" id="rotateG_01"></div>
                  <div class="blockG" id="rotateG_02"></div>
                  <div class="blockG" id="rotateG_03"></div>
                  <div class="blockG" id="rotateG_04"></div>
                  <div class="blockG" id="rotateG_05"></div>
                  <div class="blockG" id="rotateG_06"></div>
                  <div class="blockG" id="rotateG_07"></div>
                  <div class="blockG" id="rotateG_08"></div>
              </div>
          </div>

          <div class="quiz" id="quiz" data-toggle="buttons">
           <label class="element-animation1 btn btn-lg btn-primary btn-block"><span class="btn-label"><i class="glyphicon glyphicon-chevron-right"></i></span> <input type="radio" name="q_answer" value="1">1 One OneOneOneOneOneOneOneOneOneOneOneOne</label>
           <label class="element-animation2 btn btn-lg btn-primary btn-block"><span class="btn-label"><i class="glyphicon glyphicon-chevron-right"></i></span> <input type="radio" name="q_answer" value="2">2 Two</label>
           <label class="element-animation3 btn btn-lg btn-primary btn-block"><span class="btn-label"><i class="glyphicon glyphicon-chevron-right"></i></span> <input type="radio" name="q_answer" value="3">3 Three</label>
           <label class="element-animation4 btn btn-lg btn-primary btn-block"><span class="btn-label"><i class="glyphicon glyphicon-chevron-right"></i></span> <input type="radio" name="q_answer" value="4">4 Four</label>
       </div>
   </div>
   <div class="modal-footer text-muted">
    <span id="answer"></span>
</div>
</div>
</div>
</div>