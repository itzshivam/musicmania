<script type="text/javascript">
	function d()
	{
		alert("h");
	}
</script>
ak