<?php $__env->startSection('content'); ?>

<script type="text/javascript" src="/js/profile/display.js"></script>
<script type="text/javascript" src="/js/profile/profile.js"></script>
<script type="text/javascript" src="/js/profile/image_upload.js"></script>
<link rel="stylesheet" type="text/css" href="/css/layout/profile_pic.css">
<link rel="stylesheet" type="text/css" href="/css/layout/image_upload.css">


<?php
   $opponent=explode(',',$profile_user->opponents);
          $my_score=explode(',', $profile_user->my_scores);
          $topic=explode(',',$profile_user->topics);
          $opponent_score=explode(',', $profile_user->opponent_scores);
          $length=count($opponent)-1;
          $result;
          $win= 0;
          $lost=0;
          for($i=0;$i<$length;$i++)
          {
             if(($my_score[$i]-$opponent_score[$i])>0)
             {
              $result[$i]='W';
              $win++;
             }

             else
             {
              $result[$i]='L';
              $lost++;
             }
          }
?>
<body onload="ring(<?php echo($win.",".$lost);?>)"> 
<div class="container">
<div class="row">
  	<div class="col-md-4" >

  		<?php

  			$src="/images/profile/".$profile_user->username;
  			if(file_exists($src."png"))
  			{
  				$src.="png";
  			}

  			else if(file_exists($src."jpg"))
  			{
  				$src.="jpg";
  			}

  			else if(file_exists($src."jpeg"))
  			{
  				$src.="jpeg";
  			}

  			else
  			{
  				$src="/images/profile/admin.jpg";
  			}
  		  
  		?>
    <figure class="snip1336">
      <img src="https://i.ytimg.com/vi/j9u1Uj5CPmg/maxresdefault.jpg" alt="sample87" />
      <figcaption>
        <img src=<?php echo $src  ?> class="profile" />
 
        
        <a href="#" id="myBtn" class="info">Change Profile Picture</a>
        <a href="#" class="info">Change Cover Picture</a>
      
    
  		<br><br>

  
  	 
  		<canvas id="myCanvas" class="user_performance">
  				
  		</canvas>
      </figcaption>
      </figure>

  		
  	</div>
    <!-- <div class="col-md-2"></div> -->
  	<div class="col-md-8">

    <button id="myBtn">Open Modal</button>

      
       <?php
          // print_r($opponent);
          // print_r($result);
          // print_r($topic);
          // // print_r($);

          for($i=0;$i<$length;$i++)
          {
            $point_diff;
            $lost_win;
          if($result[$i]=='W')
          {
            $lost_win=" DEFEATED ";
            $point_diff=$my_score[$i]-$opponent_score[$i];
          }

          else
          {
            $lost_win=" LOST FROM ";
            $point_diff=$opponent_score[$i]-$my_score[$i];
          }

          $str="<div id='recent_achivements' style='padding:50px;margin:50px;background:rgba(255, 71, 0, 0.92)' >".

              $profile_user->username." ".$lost_win." ".$opponent[$i]." in the topic ".strtoupper($topic[$i])
          ." with the gap of ".$point_diff." points "."</div>";
          echo ($str);

        }
       ?>
       
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>