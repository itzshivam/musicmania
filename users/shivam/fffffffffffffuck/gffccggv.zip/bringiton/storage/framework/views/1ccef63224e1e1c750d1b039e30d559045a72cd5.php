<?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="/css/layout/profile_pic.css">


<div class="container">
  <div class="row">
    <div class="col-md-4" >
      <?php

        $src="/images/profile/".$user->username;
        if(file_exists($src."png"))
        {
          $src.="png";
        }

        else if(file_exists($src."jpg"))
        {
          $src.="jpg";
        }

        else if(file_exists($src."jpeg"))
        {
          $src.="jpeg";
        }

        else
        {
          $src="/images/profile/admin.jpg";
        }
      ?>
      <figure class="snip1336">
      <img src="https://i.ytimg.com/vi/j9u1Uj5CPmg/maxresdefault.jpg" alt="sample87" />
      <figcaption>
        <img src=<?php echo $src  ?> class="profile" />
 
        
        <a href="/create/topic" class="info">Create Topic</a>
    
      <br><br>
      </figcaption>
      </figure>
      <br><br>
    </div>
    <div class="col-md-8">.col-md-8</div>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>