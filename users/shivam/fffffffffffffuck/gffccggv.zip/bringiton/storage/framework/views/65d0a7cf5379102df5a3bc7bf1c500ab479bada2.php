<?php $__env->startSection('content'); ?>
	
	
<head>
	<script type="text/javascript" src="/js/admin/home.js"></script>
  <script type="text/javascript" src="js/admin/view_questions.js"></script>

</head>

<div class="container">
<div id="questions_page">

</div>
  <div class="row">
    <div class="col-md-4 profile-sidebar" >
      <?php

        $src="/images/profile/".$user->username;
        if(file_exists($src."png"))
        {
          $src.="png";
        }

        else if(file_exists($src."jpg"))
        {
          $src.="jpg";
        }

        else if(file_exists($src."jpeg"))
        {
          $src.="jpeg";
        }

        else
        {
          $src="/images/profile/admin.jpg";
        }
        $str="<img width='200' height='200' class='profile-pic img-circle' src='".$src."'/>";
        echo($str);
        $win=1;
        $draw=2;
        $lost=3;
        $total=$win+$lost+$draw;
      ?>
      <br><br>
     <a href="/create/topic"><button class="btn btn-info glyphicon glyphicon-circle-arrow-right"> Create Topic</button></a>

      <div class="user_performance">
        <span   style=<?php echo("'width:".($win*120)/$total."'");?>>win</span>
        <span style=<?php echo("'width:".($draw*120)/$total."'");?>>draw</span>
        <span  style=<?php echo("'width:".($lost*120)/$total."'");?>>lost</span>        
      </div>
    
      <div class="user_performance">
        <span>win</span>
        <span>draw</span>
        <span>lost</span>       
      </div>
      <div class="user_performance">
        <span><?php echo($user->games_win);?></span>
        <span>draw</span>
        <span><?php echo($user->games_played-$user->games_win);?></span>        
      </div>
      
    </div>
    <div class="col-md-8">
    	<div class="table-responsive">
    		<table class="table table-striped table-hover	">
    		<?php
    		foreach ($new_topics as $topic_ob) 
    		{
    			$str="
    			<tr>
    				<td> Topic : ".$topic_ob->topic." Category : ".$topic_ob->category." Creator : ".$topic_ob->username."</td>

    				<td style='text-align:right'>
            <button onclick=\"display_questions('".$topic_ob->topic."','".$topic_ob->category."','".$topic_ob->username."')\"> view 
            </button></td>
    				

    			</tr>";

    			echo($str);
    				
    		}
			?>
    		</table>
    	</div>
    </div>
</div>
</div>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>