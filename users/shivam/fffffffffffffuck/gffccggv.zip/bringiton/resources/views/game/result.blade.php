@extends('layouts.app')


@section('content')

<link rel="stylesheet" type="text/css" href="/css/layout/profile_pic.css">

	<div id=container>
    <div class="row" >
        <div class="col-md-10 col-md-offset-1" >
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align: center; background: rgba(0, 0	, 0, 0.92);"><font size="5" color="#fff">Congratulations!!</font></div>

                <div class="panel-body" style="background: #1500FF;">
                <div align="center">
          			<img src="/images/result/congratulation.png" height="200" width="300" >
          		</div>
                   <font size="4" color="#fff">
                  	<div class="row" >
                  		<div class="col-md-3"></div>
                  		
                  		<div class="col-md-4">

                  			<img src="/images/profile/souvik.jpg" height="120" width="120">
                  		<br>
                  		Your Score :<br>500
                  		<br>
                  		</div>
                  		<div class="col-md-4">
                  			<img src="/images/profile/shivam.jpeg" height="120" width="120">
                  			<br>
                  		Opponents Score :<br> 5</div>
                  	</div>
                  	</font>
                </div>
            </div>
        </div>
    </div>
   </div>

@endsection

