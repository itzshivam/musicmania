@extends('/layouts/app')

@section('content')
	
	
<head>
	<script type="text/javascript" src="/js/admin/home.js"></script>
  <script type="text/javascript" src="js/admin/view_questions.js"></script>
  <link rel="stylesheet" type="text/css" href="/css/layout/profile_pic.css">

</head>

<div class="container">
<div id="questions_page">

</div>
  <div class="row">
    <div class="col-md-4" >
      <?php

        $src="images/profile/".$user->username;
        if(file_exists($src.".png"))
        {
          $src.=".png";
        }

        else if(file_exists($src.".jpg"))
        {
          $src.=".jpg";
        }

        else if(file_exists($src.".jpeg"))
        {
          $src.=".jpeg";
        }

        else
        {
          $src="images/profile/admin.jpg";
        }
        
        $win=1;
        $draw=2;
        $lost=3;
        $total=$win+$lost+$draw;
      ?>
      <figure class="snip1336">
      <img src="https://i.ytimg.com/vi/j9u1Uj5CPmg/maxresdefault.jpg" alt="sample87" />
      <figcaption>
        <img src=<?php echo "/".$src ; ?> class="profile" />
 
        
        <a href="/create/topic" class="info">Create Topic</a>
    
      <br><br>
      </figcaption>
      </figure>
      <br><br>


      
    </div>
    <div class="col-md-6">
    	<div class="table-responsive">
    		<table class="table table-striped table-hover	">
    		<?php
    		foreach ($new_topics as $topic_ob) 
    		{
    			$str="
    			<tr>
    				<td> Topic : ".$topic_ob->topic." Category : ".$topic_ob->category." Creator : ".$topic_ob->username."</td>

    				<td style='text-align:right'>
            <button onclick=\"display_questions('".$topic_ob->topic."','".$topic_ob->category."','".$topic_ob->username."')\"> view 
            </button></td>
    				

    			</tr>";

    			echo($str);
    				
    		}
			?>
    		</table>
    	</div>
    </div>
</div>
</div>

	
@endsection