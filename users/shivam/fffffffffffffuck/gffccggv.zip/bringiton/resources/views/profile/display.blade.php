
@extends('layouts/app')


@section('content')

<script type="text/javascript" src="/js/profile/profile.js"></script>
<link rel="stylesheet" type="text/css" href="/css/layout/profile_pic.css">
<?php
   $opponent=explode(',',$profile_user->opponents);
          $my_score=explode(',', $profile_user->my_scores);
          $topic=explode(',',$profile_user->topics);
          $opponent_score=explode(',', $profile_user->opponent_scores);
          $length=count($opponent)-1;
          $result;
          $win= 0;
          $lost=0;
          for($i=0;$i<$length;$i++)
          {
             if(($my_score[$i]-$opponent_score[$i])>0)
             {
              $result[$i]='W';
              $win++;
             }

             else
             {
              $result[$i]='L';
              $lost++;
             }
          }
?>
<body onload="ring(<?php echo($win.",".$lost);?>)">
<div class="container">
<div class="row">
  	<div class="col-md-4" >
  		<?php

  			$src="images/profile/".$profile_user->username;
  			if(file_exists($src.".png"))
  			{
  				$src.=".png";
  			}

  			else if(file_exists($src.".jpg"))
  			{
  				$src.=".jpg";
  			}

  			else if(file_exists($src.".jpeg"))
  			{
  				$src.=".jpeg";
  			}

  			else
  			{
  				$src="images/profile/admin.jpg";
  			}
  			  	
  		?>
      <figure class="snip1336">
      <img src="https://i.ytimg.com/vi/j9u1Uj5CPmg/maxresdefault.jpg" alt="sample87" />
      <figcaption>
        <img src=<?php echo "/".$src;  ?> class="profile" />

        <a href="#" class="follow">Follow</a>
        <a href="#" class="info">Play</a>

    
      <br><br>

  
     
      <canvas id="myCanvas" class="user_performance">
          
      </canvas>

  		<br><br>
      </figcaption>
      </figure>

      <div id="active">

      Acitve : 
       <?php
   
        $time_difference=(time()-strtotime($profile_user->updated_at));
        echo($profile_user->updated_at);
        echo($time_difference);

        if($time_difference>35)
        {
          echo(round(($time_difference/60),2). " minutes ago");
        }

        else echo("Now");
      ?>
      </div>
     
  		
  	</div>
    <div class="col-md-8">
      
       <?php
          // print_r($opponent);
          // print_r($result);
          // print_r($topic);
          // // print_r($);

          for($i=0;$i<$length;$i++)
          {
            $point_diff;
            $lost_win;
          if($result[$i]=='W')
          {
            $lost_win=" DEFEATED ";
            $point_diff=$my_score[$i]-$opponent_score[$i];
          }

          else
          {
            $lost_win=" LOST FROM ";
            $point_diff=$opponent_score[$i]-$my_score[$i];
          }

          $str="<div id='recent_achivements' style='padding:50px;margin:50px;background:rgba(255, 71, 0, 0.92)' >".

              $profile_user->username." ".$lost_win." ".$opponent[$i]." in the topic ".strtoupper($topic[$i])
          ." with the gap of ".$point_diff." points "."</div>";
          echo ($str);

        }
       ?>
       
    </div>
</div>
</div>
</body>


@endsection