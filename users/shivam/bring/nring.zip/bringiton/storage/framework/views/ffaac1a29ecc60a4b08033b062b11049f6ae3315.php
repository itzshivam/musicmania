<?php $__env->startSection('content'); ?>

<script type="text/javascript" src="/js/profile/display.js"></script>
<script type="text/javascript" src="/js/profile/profile.js"></script>

<?php
   $opponent=explode(',',$profile_user->opponents);
          $my_score=explode(',', $profile_user->my_scores);
          $topic=explode(',',$profile_user->topics);
          $opponent_score=explode(',', $profile_user->opponent_scores);
          $length=count($opponent)-1;
          $result;
          $win=10;
          $lost=0;
          for($i=0;$i<$length;$i++)
          {
             if(($my_score[$i]-$opponent_score[$i])>0)
             {
              $result[$i]='W';
              $win++;
             }

             else
             {
              $result[$i]='L';
              $lost++;
             }
          }
?>
<body onload="ring(<?php echo($win.",".$lost);?>)"> 
<div class="container">
<div class="row">
  	<div class="col-md-4 profile-sidebar" >
  		<?php

  			$src="/images/profile/".$profile_user->username;
  			if(file_exists($src."png"))
  			{
  				$src.="png";
  			}

  			else if(file_exists($src."jpg"))
  			{
  				$src.="jpg";
  			}

  			else if(file_exists($src."jpeg"))
  			{
  				$src.="jpeg";
  			}

  			else
  			{
  				$src="/images/profile/admin.jpg";
  			}
  			$str="<img width='200' height='200' class='profile-pic img-circle' src='".$src."'/>";
  			echo($str);
  		?>
  		<br><br>

  		<div class="user_performance">
      <?php
      $ans="";
      for ($i=$length-1 ;($i>=0 && $i>($length-10));$i--)
        $ans=$result[$i]." ".$ans;

      echo($ans);
      ?>		
  		</div>
  	
  		<canvas id="myCanvas" class="user_performance">
  				
  		</canvas>
      
      <div id="active">

      Acitve : 
       <?php
            // date_default_timezone_set("Asia/Kolkata");

        $time_difference=(time()-strtotime($profile_user->updated_at));
        echo(time()." time is ");
        echo(strtotime($profile_user->updated_at)."<br>");
        echo($time_difference);

        if($time_difference>35)
        {
          echo(round(($time_difference/60),2). " minutes ago");
        }

        else echo("Now");
      ?>
      </div>
  		
  	</div>
  	<div class="col-md-8">
      <div class="row">
       <?php
          // print_r($opponent);
          // print_r($result);
          // print_r($topic);
          // // print_r($);

          for($i=0;$i<$length;$i++)
          {
            $point_diff;
            $lost_win;
          if($result[$i]=='W')
          {
            $lost_win=" DEFEATED ";
            $point_diff=$my_score[$i]-$opponent_score[$i];
          }

          else
          {
            $lost_win=" LOST FROM ";
            $point_diff=$opponent_score[$i]-$my_score[$i];
          }

          $str="<div id='recent_achivements' class='col-md-12'>".

              $profile_user->username." ".$lost_win." ".$opponent[$i]." in the topic ".strtoupper($topic[$i])
          ." with the gap of ".$point_diff." points "."</div>";
          echo ($str);

        }
       ?>
       </div>
    </div>
</div>
</div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>