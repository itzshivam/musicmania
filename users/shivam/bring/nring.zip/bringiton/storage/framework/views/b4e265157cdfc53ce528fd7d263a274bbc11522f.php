<?php $__env->startSection('content'); ?>

	
	<script type="text/javascript">
		name="";
		category="";
		questions=[];
		images=[];
		counter=1;
		function get_question()
		 {	
		 	
			var xmlhttp=new XMLHttpRequest();
			xmlhttp.onreadystatechange=function()			
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					var question = document.createElement("div");
					question.innerHTML=xmlhttp.responseText;
					document.getElementsByClassName('questions')[0].appendChild(question);
					if(counter<2)
					{
						var buttons=document.getElementById('buttons');
						// console.log(buttons.childNodes[3]);

						buttons.removeChild(buttons.childNodes[3]);
					}
				}
			}

			xmlhttp.open("GET","/create/question");
			xmlhttp.send();
		}
	

		function set_question()
		{	
			counter++;
			que=document.getElementById('question').value;
			question=[];
			question.push(escape(que));
			for(var i=1;i<=4;i++)
			question.push(escape(document.getElementById(i).value));
			questions.push((question));
			if(document.getElementById('file').value)
			{
				images.push(document.getElementById('file').value);
			}
			// document.getElementById('newfile').value=document.getElementById('file').value
			get_question();
		}

		function update_topic()
		{
			
			name=escape(document.getElementById('name').value);
			category=escape(document.getElementById('category').value);
			get_question();//set_questions
			
								
		}

		function submit_questions()
		{

			var xmlhttp=new XMLHttpRequest();
			xmlhttp.onreadystatechange=function()			
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementsByClassName('panel-body')[0].innerHTML=counter+". "+xmlhttp.responseText;
					
					
				}
			}
			xmlhttp.open("GET","/submit/"+name+"/"+category+"/"+(questions)+"/"+questions.length,true);
			xmlhttp.send();
			document.location="/home";
		

		}


	</script>

	<div id=container>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Create Your Own Topics Here</div>

                <div class="panel-body">
          
                   Write Name and Category of the topic you want to create
                   <br>
                   Name <input type="text" id="name"  placeholder="name of topic">
                   <br>
                   Category <input type="text" id="category" placeholder="category of topic">
                   <div class="questions"></div>
                   <button class="btn btn-danger glyphicon glyphicon-circle-arrow-right" onclick="update_topic()"> Next </button>
                </div>
            </div>
        </div>
    </div>
<!-- <div id="newfile"></div>
 -->    </div>
<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>