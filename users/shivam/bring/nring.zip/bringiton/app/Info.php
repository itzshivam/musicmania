<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Info extends Model
{
    //
    public static function get_info($username)
    {
    	return Info::where('username',$username)->first();
    }
}
