

<textarea id="question" style="width:80%;min-height:50px;height: auto">		delete this text and write your question here
</textarea>
<pre>
<input id="1" type="text">		<input id="2" type="text">
						
<input id="3" type="text">		<input id="4" type="text">

<input type="file" id="file">
<div id="buttons">
<!-- <button class="btn btn-danger glyphicon glyphicon-circle-arrow-right" id="next_question" onclick="set_question()"> Next</button> -->
<!-- 
<button class="btn btn-primary"  onclick="submit_questions()">Submit</button> -->
</div>
</pre>