
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>404-page not found</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="stylesheet" href="/css/404.css">
<link href='http://fonts.googleapis.com/css?family=Condiment' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="wrap">
<div class="main">
	<div class="banner">
		<img src="/images/errors/no_user.png" alt="" />
	</div>
	<div class="text">
		<h1>Username does not exists!...</h1>
		<p>Sorry!Evidently the username you were looking for has either been moved or no longer exist,,</p>
	</div>
</div>
<div class="footer">
</div>
</div>
</body>
</html>

