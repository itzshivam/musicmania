
	function display_question(question,option1,option2,option3,option4,img_src=false)
	{
			document.getElementById('qid').innerHTML=question;
	}

	function validate_ans(question_id,selected_option)
		{
			//alert("a");
			// console.log(selected_option.innerHTML);
			var xmlhttpobject=new XMLHttpRequest();

			xmlhttpobject.onreadystatechange=function(){
				if(xmlhttpobject.readyState==4 && xmlhttpobject.status==200)
				{
					document.getElementById('return').innerHTML=xmlhttpobject.responseText;
				};
			}

			xmlhttpobject.open('GET','/game/validate_ans/'+question_id+'/'+selected_option.innerHTML);
			xmlhttpobject.send();

		}

	function display_scores()
		{
			var xmlhttpobject=new XMLHttpRequest();
			xmlhttpobject.onreadystatechange=function()
			{
				if(xmlhttpobject.readyState==4 && xmlhttpobject.status==200)
				{
					document.getElementById('scores').innerHTML=xmlhttpobject.responseText;
				};

			}

			xmlhttpobject.open('GET','/game/display_scores');
			xmlhttpobject.send();

			set_display_scores=setTimeout(display_scores,500);

		}

	function warning()
		{
			return "You will loose the game if you refresh or close the window";
		}
		window.addEventListener('load',display_scores,false);


