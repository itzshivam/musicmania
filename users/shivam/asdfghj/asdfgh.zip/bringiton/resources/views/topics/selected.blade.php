@extends('/layouts/app')

@section('content')
<div id="container">

	<div id="row">
	<div class="col-md-4">
	<?php
		 {
		 	/// testing
		 	// $s="<a href ='".url('/home')."'> click </a>";
		 	$url='/topics/'.$topic->topic.'/play';
		 	$button="<button onclick='".url($url)."'><a href ='".url($url)."'> Play </a></button>";
				echo($button."<br>");
		}
	?>
	</div>
	<div class="col-md-8">
	   <?php
	   	 // foreach ($ranklist as $rank) {
	   	 // 	# code...
	   	 // 	echo($rank->rank);
	   	 // }
	   ?>
	</div>
	</div>
@endsection