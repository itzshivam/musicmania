<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Info;

use Auth;

use App\User;

use App\Http\Requests;

class ProfileController extends Controller
{
    //


	public function __construct()
	{
        $this->middleware('auth');
	}

    public function display($profile_name)
    {
    	$profile_user=Info::where('username',$profile_name)->first();

        if(sizeof($profile_user)==0)
        {
            return view("/errors/no_user");
        }


        else if($profile_user->username==Auth::user()->username)
        {
            return view("/profile/self",compact('profile_user'));
        }


    	return view('/profile/display',compact('profile_user'));
    }


    public function update()
    {

        // code here
    }

    public function update_online_info()
    {
        $user=Auth::user();
        // date_default_timezone_set("Asia/Kolkata");
        // echo(date_default_timezone_get());
        Info::where('username',$user->username)->update(['updated_at'=>date('d-m-y H:i:s ')]);

        return "user_logged_in updated";
       
    }

    public function get_online_info()
    {

    }

    public  function view_questions()
    {
        //code
    }

    public function delete_questions()
    {
        //code
    }

}
