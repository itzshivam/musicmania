
	// y=0;
	question_change_speed=10000;
	question_num=1;
	max_questions=4;
	stop_score_upadte=0;
	click="disabled";




	function display_question()
	{
		// y++;
		if(question_num>1)
		document.getElementById(question_num-1).style.display='none';
		// document.getElementById(question_num-1).style.display='none';
		document.getElementById(question_num).style.display='block';
		click="enabled";
		question_num++;
		set_time_for_question=setTimeout('display_question()',question_change_speed);
		if(question_num>max_questions)
		{
			clearTimeout(set_time_for_question);
			// clearTimeout(set_display_scores);
			// stop_score_upadte=1;
			show_results_page();
		}
	}


	function validate_ans(question_id,selected_option)
		{
			//alert("a");
			if(click=="enabled")
			{
				click="disabled";
				console.log("hey"+selected_option.innerText+"bye ");
			console.log(selected_option.innerText);
			var xmlhttpobject=new XMLHttpRequest();

			xmlhttpobject.onreadystatechange=function(){
				// if(xmlhttpobject.readyState==4 && xmlhttpobject.status==200)
				// {
				// 	// document.getElementById('return1').innerHTML=xmlhttpobject.responseText;
				// };
			}

			xmlhttpobject.open('GET','/game/validate_ans/'+question_id+'/'+selected_option.innerText);
			xmlhttpobject.send();
			}

		}

	function display_scores()
		{
			var xmlhttpobject=new XMLHttpRequest();
			xmlhttpobject.onreadystatechange=function()
			{
				if(xmlhttpobject.readyState==4 && xmlhttpobject.status==200)
				{
					document.getElementById('scores').innerHTML=xmlhttpobject.responseText;
				};

			}

			xmlhttpobject.open('GET','/game/display_scores');
			xmlhttpobject.send();

			set_display_scores=setTimeout(display_scores,600);

			// if(stop_score_update==1)
			// {
			// 	clearTimeout(set_display_scores);
			// }

		}


	function show_results_page()
	{

		// to be done
	}

	function warning()
		{
			return "You will loose the game if you refresh or close the window";
		}
		window.addEventListener('load',display_scores,false);


